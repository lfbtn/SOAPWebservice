package br.lb.soap;

import java.io.Serializable;

public class Fuel implements Serializable{

	private static final long serialVersionUID = -5577579081118070434L;
	
	private int id;
	private String name;
	private String unidade;
	private String numerodePostos;
	private String precoMedioConsumidor;
	private String desvioPadraoConsumidor;
	private String precoMinimoConsumidor;
	private String precoMaximoConsumidor;
	private String margemMedia;
	private String precoMedioDistribuidora;
	private String desvioPadraoDistribuidora;
	private String precoMinimoDistribuidora;
	private String precoMaximoDistribuidora;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUnidade() {
		return unidade;
	}
	public void setUnidade(String unidade) {
		this.unidade = unidade;
	}
	public String getNumerodePostos() {
		return numerodePostos;
	}
	public void setNumerodePostos(String numerodePostos) {
		this.numerodePostos = numerodePostos;
	}
	public String getPrecoMedioConsumidor() {
		return precoMedioConsumidor;
	}
	public void setPrecoMedioConsumidor(String precoMedioConsumidor) {
		this.precoMedioConsumidor = precoMedioConsumidor;
	}
	public String getDesvioPadraoConsumidor() {
		return desvioPadraoConsumidor;
	}
	public void setDesvioPadraoConsumidor(String desvioPadraoConsumidor) {
		this.desvioPadraoConsumidor = desvioPadraoConsumidor;
	}
	public String getPrecoMinimoConsumidor() {
		return precoMinimoConsumidor;
	}
	public void setPrecoMinimoConsumidor(String precoMinimoConsumidor) {
		this.precoMinimoConsumidor = precoMinimoConsumidor;
	}
	public String getPrecoMaximoConsumidor() {
		return precoMaximoConsumidor;
	}
	public void setPrecoMaximoConsumidor(String precoMaximoConsumidor) {
		this.precoMaximoConsumidor = precoMaximoConsumidor;
	}
	public String getMargemMedia() {
		return margemMedia;
	}
	public void setMargemMedia(String margemMedia) {
		this.margemMedia = margemMedia;
	}
	public String getPrecoMedioDistribuidora() {
		return precoMedioDistribuidora;
	}
	public void setPrecoMedioDistribuidora(String precoMedioDistribuidora) {
		this.precoMedioDistribuidora = precoMedioDistribuidora;
	}
	public String getDesvioPadraoDistribuidora() {
		return desvioPadraoDistribuidora;
	}
	public void setDesvioPadraoDistribuidora(String desvioPadraoDistribuidora) {
		this.desvioPadraoDistribuidora = desvioPadraoDistribuidora;
	}
	public String getPrecoMinimoDistribuidora() {
		return precoMinimoDistribuidora;
	}
	public void setPrecoMinimoDistribuidora(String precoMinimoDistribuidora) {
		this.precoMinimoDistribuidora = precoMinimoDistribuidora;
	}
	public String getPrecoMaximoDistribuidora() {
		return precoMaximoDistribuidora;
	}
	public void setPrecoMaximoDistribuidora(String precoMaximoDistribuidora) {
		this.precoMaximoDistribuidora = precoMaximoDistribuidora;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Fuel [name=" + name + ", unidade=" + unidade + ", numerodePostos=" + numerodePostos
				+ ", precoMedioConsumidor=" + precoMedioConsumidor + ", desvioPadraoConsumidor="
				+ desvioPadraoConsumidor + ", precoMinimoConsumidor=" + precoMinimoConsumidor
				+ ", precoMaximoConsumidor=" + precoMaximoConsumidor + ", margemMedia=" + margemMedia
				+ ", precoMedioDistribuidora=" + precoMedioDistribuidora + ", desvioPadraoDistribuidora="
				+ desvioPadraoDistribuidora + ", precoMinimoDistribuidora=" + precoMinimoDistribuidora
				+ ", precoMaximoDistribuidora=" + precoMaximoDistribuidora + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	
	
}
