package br.lb.soap;

public interface FuelService {

	public boolean addFuel(Fuel p);
	
	public boolean deleteFuel(int id);
	
	public Fuel getFuel(int id);
	
	public Fuel[] getAllFuels();
}
