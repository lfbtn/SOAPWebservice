package br.lb.soap;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class FuelServiceImpl implements FuelService {

	private static Map<Integer,Fuel> myFuelList = new HashMap<Integer,Fuel>();
	
	@Override
	public boolean addFuel(Fuel p) {
		if(myFuelList.get(p.getId()) != null) return false;
		myFuelList.put(p.getId(), p);
		return true;
	}

	@Override
	public boolean deleteFuel(int id) {
		if(myFuelList.get(id) == null) return false;
		myFuelList.remove(id);
		return true;
	}

	@Override
	public Fuel getFuel(int id) {
		return myFuelList.get(id);
	}

	@Override
	public Fuel[] getAllFuels() {
		Set<Integer> ids = myFuelList.keySet();
		Fuel[] p = new Fuel[ids.size()];
		int i=0;
		for(Integer id : ids){
			p[i] = myFuelList.get(id);
			i++;
		}
		return p;
	}

}
