/**
 * Fuel.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.lb.soap;

public class Fuel  implements java.io.Serializable {
    private java.lang.String desvioPadraoConsumidor;

    private java.lang.String desvioPadraoDistribuidora;

    private int id;

    private java.lang.String margemMedia;

    private java.lang.String name;

    private java.lang.String numerodePostos;

    private java.lang.String precoMaximoConsumidor;

    private java.lang.String precoMaximoDistribuidora;

    private java.lang.String precoMedioConsumidor;

    private java.lang.String precoMedioDistribuidora;

    private java.lang.String precoMinimoConsumidor;

    private java.lang.String precoMinimoDistribuidora;

    private java.lang.String unidade;

    public Fuel() {
    }

    public Fuel(
           java.lang.String desvioPadraoConsumidor,
           java.lang.String desvioPadraoDistribuidora,
           int id,
           java.lang.String margemMedia,
           java.lang.String name,
           java.lang.String numerodePostos,
           java.lang.String precoMaximoConsumidor,
           java.lang.String precoMaximoDistribuidora,
           java.lang.String precoMedioConsumidor,
           java.lang.String precoMedioDistribuidora,
           java.lang.String precoMinimoConsumidor,
           java.lang.String precoMinimoDistribuidora,
           java.lang.String unidade) {
           this.desvioPadraoConsumidor = desvioPadraoConsumidor;
           this.desvioPadraoDistribuidora = desvioPadraoDistribuidora;
           this.id = id;
           this.margemMedia = margemMedia;
           this.name = name;
           this.numerodePostos = numerodePostos;
           this.precoMaximoConsumidor = precoMaximoConsumidor;
           this.precoMaximoDistribuidora = precoMaximoDistribuidora;
           this.precoMedioConsumidor = precoMedioConsumidor;
           this.precoMedioDistribuidora = precoMedioDistribuidora;
           this.precoMinimoConsumidor = precoMinimoConsumidor;
           this.precoMinimoDistribuidora = precoMinimoDistribuidora;
           this.unidade = unidade;
    }


    /**
     * Gets the desvioPadraoConsumidor value for this Fuel.
     * 
     * @return desvioPadraoConsumidor
     */
    public java.lang.String getDesvioPadraoConsumidor() {
        return desvioPadraoConsumidor;
    }


    /**
     * Sets the desvioPadraoConsumidor value for this Fuel.
     * 
     * @param desvioPadraoConsumidor
     */
    public void setDesvioPadraoConsumidor(java.lang.String desvioPadraoConsumidor) {
        this.desvioPadraoConsumidor = desvioPadraoConsumidor;
    }


    /**
     * Gets the desvioPadraoDistribuidora value for this Fuel.
     * 
     * @return desvioPadraoDistribuidora
     */
    public java.lang.String getDesvioPadraoDistribuidora() {
        return desvioPadraoDistribuidora;
    }


    /**
     * Sets the desvioPadraoDistribuidora value for this Fuel.
     * 
     * @param desvioPadraoDistribuidora
     */
    public void setDesvioPadraoDistribuidora(java.lang.String desvioPadraoDistribuidora) {
        this.desvioPadraoDistribuidora = desvioPadraoDistribuidora;
    }


    /**
     * Gets the id value for this Fuel.
     * 
     * @return id
     */
    public int getId() {
        return id;
    }


    /**
     * Sets the id value for this Fuel.
     * 
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }


    /**
     * Gets the margemMedia value for this Fuel.
     * 
     * @return margemMedia
     */
    public java.lang.String getMargemMedia() {
        return margemMedia;
    }


    /**
     * Sets the margemMedia value for this Fuel.
     * 
     * @param margemMedia
     */
    public void setMargemMedia(java.lang.String margemMedia) {
        this.margemMedia = margemMedia;
    }


    /**
     * Gets the name value for this Fuel.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this Fuel.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the numerodePostos value for this Fuel.
     * 
     * @return numerodePostos
     */
    public java.lang.String getNumerodePostos() {
        return numerodePostos;
    }


    /**
     * Sets the numerodePostos value for this Fuel.
     * 
     * @param numerodePostos
     */
    public void setNumerodePostos(java.lang.String numerodePostos) {
        this.numerodePostos = numerodePostos;
    }


    /**
     * Gets the precoMaximoConsumidor value for this Fuel.
     * 
     * @return precoMaximoConsumidor
     */
    public java.lang.String getPrecoMaximoConsumidor() {
        return precoMaximoConsumidor;
    }


    /**
     * Sets the precoMaximoConsumidor value for this Fuel.
     * 
     * @param precoMaximoConsumidor
     */
    public void setPrecoMaximoConsumidor(java.lang.String precoMaximoConsumidor) {
        this.precoMaximoConsumidor = precoMaximoConsumidor;
    }


    /**
     * Gets the precoMaximoDistribuidora value for this Fuel.
     * 
     * @return precoMaximoDistribuidora
     */
    public java.lang.String getPrecoMaximoDistribuidora() {
        return precoMaximoDistribuidora;
    }


    /**
     * Sets the precoMaximoDistribuidora value for this Fuel.
     * 
     * @param precoMaximoDistribuidora
     */
    public void setPrecoMaximoDistribuidora(java.lang.String precoMaximoDistribuidora) {
        this.precoMaximoDistribuidora = precoMaximoDistribuidora;
    }


    /**
     * Gets the precoMedioConsumidor value for this Fuel.
     * 
     * @return precoMedioConsumidor
     */
    public java.lang.String getPrecoMedioConsumidor() {
        return precoMedioConsumidor;
    }


    /**
     * Sets the precoMedioConsumidor value for this Fuel.
     * 
     * @param precoMedioConsumidor
     */
    public void setPrecoMedioConsumidor(java.lang.String precoMedioConsumidor) {
        this.precoMedioConsumidor = precoMedioConsumidor;
    }


    /**
     * Gets the precoMedioDistribuidora value for this Fuel.
     * 
     * @return precoMedioDistribuidora
     */
    public java.lang.String getPrecoMedioDistribuidora() {
        return precoMedioDistribuidora;
    }


    /**
     * Sets the precoMedioDistribuidora value for this Fuel.
     * 
     * @param precoMedioDistribuidora
     */
    public void setPrecoMedioDistribuidora(java.lang.String precoMedioDistribuidora) {
        this.precoMedioDistribuidora = precoMedioDistribuidora;
    }


    /**
     * Gets the precoMinimoConsumidor value for this Fuel.
     * 
     * @return precoMinimoConsumidor
     */
    public java.lang.String getPrecoMinimoConsumidor() {
        return precoMinimoConsumidor;
    }


    /**
     * Sets the precoMinimoConsumidor value for this Fuel.
     * 
     * @param precoMinimoConsumidor
     */
    public void setPrecoMinimoConsumidor(java.lang.String precoMinimoConsumidor) {
        this.precoMinimoConsumidor = precoMinimoConsumidor;
    }


    /**
     * Gets the precoMinimoDistribuidora value for this Fuel.
     * 
     * @return precoMinimoDistribuidora
     */
    public java.lang.String getPrecoMinimoDistribuidora() {
        return precoMinimoDistribuidora;
    }


    /**
     * Sets the precoMinimoDistribuidora value for this Fuel.
     * 
     * @param precoMinimoDistribuidora
     */
    public void setPrecoMinimoDistribuidora(java.lang.String precoMinimoDistribuidora) {
        this.precoMinimoDistribuidora = precoMinimoDistribuidora;
    }


    /**
     * Gets the unidade value for this Fuel.
     * 
     * @return unidade
     */
    public java.lang.String getUnidade() {
        return unidade;
    }


    /**
     * Sets the unidade value for this Fuel.
     * 
     * @param unidade
     */
    public void setUnidade(java.lang.String unidade) {
        this.unidade = unidade;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Fuel)) return false;
        Fuel other = (Fuel) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.desvioPadraoConsumidor==null && other.getDesvioPadraoConsumidor()==null) || 
             (this.desvioPadraoConsumidor!=null &&
              this.desvioPadraoConsumidor.equals(other.getDesvioPadraoConsumidor()))) &&
            ((this.desvioPadraoDistribuidora==null && other.getDesvioPadraoDistribuidora()==null) || 
             (this.desvioPadraoDistribuidora!=null &&
              this.desvioPadraoDistribuidora.equals(other.getDesvioPadraoDistribuidora()))) &&
            this.id == other.getId() &&
            ((this.margemMedia==null && other.getMargemMedia()==null) || 
             (this.margemMedia!=null &&
              this.margemMedia.equals(other.getMargemMedia()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.numerodePostos==null && other.getNumerodePostos()==null) || 
             (this.numerodePostos!=null &&
              this.numerodePostos.equals(other.getNumerodePostos()))) &&
            ((this.precoMaximoConsumidor==null && other.getPrecoMaximoConsumidor()==null) || 
             (this.precoMaximoConsumidor!=null &&
              this.precoMaximoConsumidor.equals(other.getPrecoMaximoConsumidor()))) &&
            ((this.precoMaximoDistribuidora==null && other.getPrecoMaximoDistribuidora()==null) || 
             (this.precoMaximoDistribuidora!=null &&
              this.precoMaximoDistribuidora.equals(other.getPrecoMaximoDistribuidora()))) &&
            ((this.precoMedioConsumidor==null && other.getPrecoMedioConsumidor()==null) || 
             (this.precoMedioConsumidor!=null &&
              this.precoMedioConsumidor.equals(other.getPrecoMedioConsumidor()))) &&
            ((this.precoMedioDistribuidora==null && other.getPrecoMedioDistribuidora()==null) || 
             (this.precoMedioDistribuidora!=null &&
              this.precoMedioDistribuidora.equals(other.getPrecoMedioDistribuidora()))) &&
            ((this.precoMinimoConsumidor==null && other.getPrecoMinimoConsumidor()==null) || 
             (this.precoMinimoConsumidor!=null &&
              this.precoMinimoConsumidor.equals(other.getPrecoMinimoConsumidor()))) &&
            ((this.precoMinimoDistribuidora==null && other.getPrecoMinimoDistribuidora()==null) || 
             (this.precoMinimoDistribuidora!=null &&
              this.precoMinimoDistribuidora.equals(other.getPrecoMinimoDistribuidora()))) &&
            ((this.unidade==null && other.getUnidade()==null) || 
             (this.unidade!=null &&
              this.unidade.equals(other.getUnidade())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDesvioPadraoConsumidor() != null) {
            _hashCode += getDesvioPadraoConsumidor().hashCode();
        }
        if (getDesvioPadraoDistribuidora() != null) {
            _hashCode += getDesvioPadraoDistribuidora().hashCode();
        }
        _hashCode += getId();
        if (getMargemMedia() != null) {
            _hashCode += getMargemMedia().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getNumerodePostos() != null) {
            _hashCode += getNumerodePostos().hashCode();
        }
        if (getPrecoMaximoConsumidor() != null) {
            _hashCode += getPrecoMaximoConsumidor().hashCode();
        }
        if (getPrecoMaximoDistribuidora() != null) {
            _hashCode += getPrecoMaximoDistribuidora().hashCode();
        }
        if (getPrecoMedioConsumidor() != null) {
            _hashCode += getPrecoMedioConsumidor().hashCode();
        }
        if (getPrecoMedioDistribuidora() != null) {
            _hashCode += getPrecoMedioDistribuidora().hashCode();
        }
        if (getPrecoMinimoConsumidor() != null) {
            _hashCode += getPrecoMinimoConsumidor().hashCode();
        }
        if (getPrecoMinimoDistribuidora() != null) {
            _hashCode += getPrecoMinimoDistribuidora().hashCode();
        }
        if (getUnidade() != null) {
            _hashCode += getUnidade().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Fuel.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://soap.lb.br", "Fuel"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desvioPadraoConsumidor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.lb.br", "desvioPadraoConsumidor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desvioPadraoDistribuidora");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.lb.br", "desvioPadraoDistribuidora"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.lb.br", "id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("margemMedia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.lb.br", "margemMedia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.lb.br", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numerodePostos");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.lb.br", "numerodePostos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("precoMaximoConsumidor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.lb.br", "precoMaximoConsumidor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("precoMaximoDistribuidora");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.lb.br", "precoMaximoDistribuidora"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("precoMedioConsumidor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.lb.br", "precoMedioConsumidor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("precoMedioDistribuidora");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.lb.br", "precoMedioDistribuidora"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("precoMinimoConsumidor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.lb.br", "precoMinimoConsumidor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("precoMinimoDistribuidora");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.lb.br", "precoMinimoDistribuidora"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("unidade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.lb.br", "unidade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
