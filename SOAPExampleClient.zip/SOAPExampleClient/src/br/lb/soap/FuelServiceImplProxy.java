package br.lb.soap;

public class FuelServiceImplProxy implements br.lb.soap.FuelServiceImpl {
  private String _endpoint = null;
  private br.lb.soap.FuelServiceImpl fuelServiceImpl = null;
  
  public FuelServiceImplProxy() {
    _initFuelServiceImplProxy();
  }
  
  public FuelServiceImplProxy(String endpoint) {
    _endpoint = endpoint;
    _initFuelServiceImplProxy();
  }
  
  private void _initFuelServiceImplProxy() {
    try {
      fuelServiceImpl = (new br.lb.soap.FuelServiceImplServiceLocator()).getFuelServiceImpl();
      if (fuelServiceImpl != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)fuelServiceImpl)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)fuelServiceImpl)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (fuelServiceImpl != null)
      ((javax.xml.rpc.Stub)fuelServiceImpl)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.lb.soap.FuelServiceImpl getFuelServiceImpl() {
    if (fuelServiceImpl == null)
      _initFuelServiceImplProxy();
    return fuelServiceImpl;
  }
  
  public br.lb.soap.Fuel getFuel(int id) throws java.rmi.RemoteException{
    if (fuelServiceImpl == null)
      _initFuelServiceImplProxy();
    return fuelServiceImpl.getFuel(id);
  }
  
  public br.lb.soap.Fuel[] getAllFuels() throws java.rmi.RemoteException{
    if (fuelServiceImpl == null)
      _initFuelServiceImplProxy();
    return fuelServiceImpl.getAllFuels();
  }
  
  public boolean deleteFuel(int id) throws java.rmi.RemoteException{
    if (fuelServiceImpl == null)
      _initFuelServiceImplProxy();
    return fuelServiceImpl.deleteFuel(id);
  }
  
  public boolean addFuel(br.lb.soap.Fuel p) throws java.rmi.RemoteException{
    if (fuelServiceImpl == null)
      _initFuelServiceImplProxy();
    return fuelServiceImpl.addFuel(p);
  }
  
  
}