/**
 * FuelServiceImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.lb.soap;

public interface FuelServiceImpl extends java.rmi.Remote {
    public br.lb.soap.Fuel getFuel(int id) throws java.rmi.RemoteException;
    public br.lb.soap.Fuel[] getAllFuels() throws java.rmi.RemoteException;
    public boolean deleteFuel(int id) throws java.rmi.RemoteException;
    public boolean addFuel(br.lb.soap.Fuel p) throws java.rmi.RemoteException;
}
